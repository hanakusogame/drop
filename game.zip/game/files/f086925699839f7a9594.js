function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Button = void 0;

      var Button =
      /** @class */
      function (_super) {
        __extends(Button, _super);

        function Button(scene, s, x, y, w, h) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          if (w === void 0) {
            w = 100;
          }

          if (h === void 0) {
            h = 50;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;

          _this.chkEnable = function (ev) {
            return true;
          }; // this.pushEvent = () => {};


          if (Button.font == null) {
            Button.font = new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 32
            });
          }

          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: w - 4,
            height: h - 4,
            cssColor: "white"
          });

          _this.append(base);

          _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w - 4
          });
          _this.label.y = (h - 4 - _this.label.height) / 2;

          _this.label.modified();

          base.append(_this.label);

          _this.pointDown.add(function (ev) {
            if (!_this.chkEnable(ev)) return;
            base.cssColor = "gray";
            base.modified();

            if (s.length !== 1) {
              _this.num = (_this.num + 1) % s.length;
              _this.label.text = s[_this.num];

              _this.label.invalidate();
            }
          });

          _this.pointUp.add(function (ev) {
            base.cssColor = "white";
            base.modified();

            _this.pushEvent(ev);
          });

          return _this;
        }

        return Button;
      }(g.FilledRect);

      exports.Button = Button;
    }, {}],
    7: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Config = void 0;

      var Button_1 = require("./Button");

      var Config =
      /** @class */
      function (_super) {
        __extends(Config, _super);

        function Config(scene, x, y) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: 250,
            height: 250,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;
          _this.volumes = [0.5, 0.8];

          _this.chkEnable = function (ev) {
            return true;
          }; // const events = [this.bgmEvent, this.seEvent];


          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.Monospace,
            size: 32
          });
          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: _this.width - 4,
            height: _this.height - 4,
            cssColor: "white"
          });

          _this.append(base);

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "設定",
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: 250
          }));
          var line = new g.FilledRect({
            scene: scene,
            x: 5,
            y: 30,
            width: 235,
            height: 2,
            cssColor: "#000000"
          });
          base.append(line);
          var strVol = ["ＢＧＭ", "効果音"];

          var _loop_1 = function _loop_1(i) {
            base.append(new g.Label({
              scene: scene,
              font: font,
              text: strVol[i],
              fontSize: 24,
              textColor: "black",
              x: 10,
              y: 50 + 50 * i
            }));
            var sprVol = new g.FrameSprite({
              scene: scene,
              src: scene.assets.volume,
              width: 32,
              height: 32,
              x: 90,
              y: 50 + 50 * i,
              frames: [0, 1]
            });
            base.append(sprVol);
            var baseVol = new g.E({
              scene: scene,
              x: 130,
              y: 50 + 50 * i,
              width: 110,
              height: 32,
              touchable: true
            });
            base.append(baseVol);
            var lineVol = new g.FilledRect({
              scene: scene,
              x: 0,
              y: 13,
              width: 110,
              height: 6,
              cssColor: "gray"
            });
            baseVol.append(lineVol);
            var cursorVol = new g.FilledRect({
              scene: scene,
              x: 110 * this_1.volumes[i] - 7,
              y: 0,
              width: 15,
              height: 32,
              cssColor: "#000000"
            });
            baseVol.append(cursorVol);
            var flgMute = false;
            baseVol.pointMove.add(function (e) {
              var posX = e.point.x + e.startDelta.x;
              if (posX < 7) posX = 7;
              if (posX > 103) posX = 103;
              cursorVol.x = posX - 7;
              cursorVol.modified();
              flgMute = posX - 7 === 0;
            });
            baseVol.pointUp.add(function (e) {
              if (flgMute) {
                sprVol.frameNumber = 1;
              } else {
                sprVol.frameNumber = 0;
              }

              sprVol.modified();
              _this.volumes[i] = cursorVol.x / 110;

              if (i === 0 && _this.bgmEvent !== undefined) {
                _this.bgmEvent(_this.volumes[i]);
              }
            });
          };

          var this_1 = this;

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          }

          var colors = ["gray", "black", "white", "green", "navy"];
          var colorNum = 0; // 背景色

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "背景色",
            fontSize: 24,
            textColor: "black",
            x: 10,
            y: 150
          }));
          base.append(new g.FilledRect({
            scene: scene,
            x: 130,
            y: 150,
            width: 110,
            height: 40,
            cssColor: "#000000"
          }));
          var sprColor = new g.FilledRect({
            scene: scene,
            x: 132,
            y: 152,
            width: 106,
            height: 36,
            cssColor: "gray",
            touchable: true
          });
          base.append(sprColor);
          sprColor.pointDown.add(function (e) {
            colorNum = (colorNum + 1) % colors.length;
            sprColor.cssColor = colors[colorNum];
            sprColor.modified();

            if (_this.colorEvent !== undefined) {
              _this.colorEvent(colors[colorNum]);
            }
          }); // ランキング表示

          var btnRank = new Button_1.Button(scene, ["ランキング"], 2, 198, 130, 45);
          base.append(btnRank);

          btnRank.pushEvent = function () {
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
              window.RPGAtsumaru.scoreboards.display(1);
            }
          }; // 閉じる


          var btnClose = new Button_1.Button(scene, ["閉じる"], 138, 198, 105, 45);
          base.append(btnClose);

          btnClose.pushEvent = function () {
            _this.hide();
          };

          return _this;
        }

        return Config;
      }(g.FilledRect);

      exports.Config = Config;
    }, {
      "./Button": 6
    }],
    8: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGame = void 0;

      var tl = require("@akashic-extension/akashic-timeline"); // メインのゲーム画面


      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame(scene) {
          var _this = this;

          var timeline = new tl.Timeline(scene);
          _this = _super.call(this, {
            scene: scene,
            x: 0,
            y: 0,
            width: 640,
            height: 360
          }) || this;
          var bg = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "white",
            opacity: 0.5
          });

          _this.append(bg);

          var mapSize = 70;
          var mapW = 6; //行(番兵含む)

          var mapH = 7; //列

          var base = new g.Sprite({
            scene: scene,
            src: scene.assets.waku,
            width: mapSize * mapW,
            height: mapSize * mapH,
            x: 20,
            y: -80,
            touchable: true
          });

          _this.append(base); // マップ


          var maps = [];

          for (var y = 0; y < mapH; y++) {
            maps[y] = [];

            for (var x = 0; x < mapW; x++) {
              var map = new Map({
                scene: scene,
                width: mapSize - 2,
                height: mapSize - 2,
                x: mapSize * x,
                y: mapSize * y,
                cssColor: "#DDDDDD"
              });
              maps[y][x] = map;
              map.num = 0;

              if (y === 0 || x === 0 || y === mapH - 1 || x === mapW - 1) {
                map.num = -1;
              } else {
                base.append(map);
              }
            }
          } //赤線


          var line = new g.FilledRect({
            scene: scene,
            x: mapSize - 4,
            y: mapSize * 2,
            width: mapSize * 4 + 8,
            height: 2,
            cssColor: "red"
          });
          base.append(line); // 次のブロック配置用

          var nextMaps = [];

          for (var i = 0; i < 3; i++) {
            var map = new Map({
              scene: scene,
              width: mapSize - 2,
              height: mapSize - 2,
              x: 450 + 100 * i,
              y: 150,
              cssColor: "#DDDDDD"
            });

            _this.append(map);

            nextMaps.push(map);
          } // パネル


          var panels = [];

          for (var i = 0; i < mapW * mapH; i++) {
            var panel = new Panel(mapSize);
            panels[i] = panel;
          } //詰み判定


          var mate = function mate() {
            for (var x = 1; x < mapW - 1; x++) {
              if (maps[1][x].panel) {
                return true;
              }
            }

            return false;
          }; //連鎖数


          var comboCnt = 0; //足す処理

          var plus = function plus(arr) {
            var arrPlus = [];
            var isClear = false;
            var score = 0;
            var srcMap = null;
            comboCnt++; //探索ルーチン

            var sub = function sub(x, y, num) {
              var cnt = 0;

              var _loop_2 = function _loop_2(i) {
                var xx = x + dx[i];
                var yy = y + dy[i];
                var dstMap = maps[yy][xx];
                var panel = dstMap.panel;

                if (panel && panel.num === num && panel !== srcMap.panel) {
                  panel.num = 0;
                  cnt++; //足すブロックに移動

                  timeline.create(panel).moveTo(srcMap.panel.x, srcMap.panel.y, 100).call(function () {
                    panel.remove();
                  });
                  panels.unshift(panel);
                  dstMap.panel = null;
                  cnt += sub(xx, yy, num); //再帰
                }
              };

              for (var i = 0; i < 4; i++) {
                _loop_2(i);
              }

              return cnt;
            };

            arr.forEach(function (p) {
              var x = p.x;
              var y = p.y;
              srcMap = maps[y][x];
              if (!srcMap.panel) return; //既に消えている場合がある

              var cnt = sub(x, y, srcMap.panel.num);
              var ans = Math.min(srcMap.panel.num + cnt, 7); //足されたブロックの処理

              if (cnt !== 0) {
                if (comboCnt > 1) {
                  //コンボ数表示用のラベル生成
                  var label_1 = new g.Label({
                    scene: scene,
                    font: scene.numFontR,
                    text: "" + comboCnt,
                    fontSize: 32,
                    x: srcMap.x + 20,
                    y: srcMap.y
                  });
                  base.append(label_1);
                  timeline.create(label_1).moveBy(0, -20, 500).wait(200).call(function () {
                    label_1.destroy();
                  });
                }

                if (ans === 7) {
                  //7のときけす
                  isClear = true;
                  var map_1 = srcMap;
                  timeline.create(map_1.panel).wait(100).call(function () {
                    map_1.panel.setNum(ans);
                  }).wait(200).rotateTo(360, 500).call(function () {
                    panels.unshift(map_1.panel);
                    map_1.panel.remove();
                    map_1.panel = null;
                  });
                  scene.playSound("se_item");
                } else {
                  //7以外のときは足す
                  var map_2 = srcMap;
                  map_2.panel.isPlus = true;
                  arrPlus.push({
                    x: x,
                    y: y
                  });
                  timeline.create(map_2.panel).scaleTo(1.3, 1.3, 100).call(function () {
                    map_2.panel.setNum(ans);
                  }).scaleTo(1.0, 1.0, 100);
                  scene.playSound("se_move");
                }

                score += Math.pow(2, ans) * 20 * comboCnt;
              }
            });

            if (score !== 0) {
              scene.addScore(score);
            } //setColor();


            if (arrPlus.length !== 0 || isClear) {
              var num = isClear ? 1000 : 250;
              timeline.create(_this).wait(num).call(function () {
                drop();
              });
            } else {
              if (!mate()) {
                //次のブロック
                isMove = false;
                next(true);
                scene.playSound("se_move");
              } else {
                //詰み処理
                for (var y = 1; y < mapH - 1; y++) {
                  var _loop_1 = function _loop_1(x) {
                    var panel = maps[y][x].panel;

                    if (panel) {
                      timeline.create(panel).wait(y * 200 + x * 20).call(function () {
                        panel.setNum(8);
                      });
                    }
                  };

                  for (var x = 1; x < mapW - 1; x++) {
                    _loop_1(x);
                  }
                }

                timeline.create(_this).wait(2000).call(function () {
                  _this.reset();
                });
                scene.playSound("se_miss");
              }
            }
          }; //落とす


          var drop = function drop() {
            // １つ落とす
            var arr = []; //足す判定をするパネル

            var sub = function sub(x, y) {
              var map = maps[y][x];

              for (; y < mapH - 1; y++) {
                if (maps[y + 1][x].panel || maps[y + 1][x].num === -1) break;
              }

              if (map !== maps[y][x]) {
                maps[y][x].panel = map.panel;
                map.panel = null;
                arr.push({
                  x: x,
                  y: y
                });
                return true;
              }

              return false;
            }; // 設置されているパネルを探す


            for (var y = mapH - 2; y >= 1; y--) {
              for (var x = 1; x <= mapW - 2; x++) {
                var map = maps[y][x];

                if (map.panel) {
                  var flg = map.panel.isPlus;
                  map.panel.isPlus = false;

                  if (!sub(x, y) && flg) {
                    arr.unshift({
                      x: x,
                      y: y
                    }); //プラスされたパネルが動いていなかった場合追加
                  }
                }
              }
            }

            setColor();
            timeline.create(_this).wait(300).call(function () {
              plus(arr);
            });
          }; // クリックイベント


          var dx = [1, 0, -1, 0];
          var dy = [0, 1, 0, -1];
          var isMove = false;
          base.pointDown.add(function (e) {
            if (!scene.isStart || isMove) return;
            var x = Math.floor(e.point.x / mapSize);
            if (x < 1 || x >= mapW - 1) return;
            nowPanel.x = x * mapSize;
            nowPanel.modified();
          });
          base.pointMove.add(function (e) {
            if (!scene.isStart || isMove) return;
            var x = Math.floor((e.point.x + e.startDelta.x) / mapSize);
            if (x < 1 || x >= mapW - 1) return;
            nowPanel.x = x * mapSize;
            nowPanel.modified();
          });
          base.pointUp.add(function (e) {
            if (!scene.isStart || isMove) return;
            var x = Math.floor((e.point.x + e.startDelta.x) / mapSize);
            if (x < 1 || x >= mapW - 1) return;
            nowPanel.x = x * mapSize;
            nowPanel.modified();
            isMove = true; //ブロック設置

            maps[1][x].panel = nowPanel;
            comboCnt = 0;
            nowPanel = null;
            drop();
          }); //色を変える処理

          var setColor = function setColor() {
            for (var y = 0; y < mapH; y++) {
              for (var x = 0; x < mapW; x++) {
                var map = maps[y][x];
                map.modified();

                if (map.panel) {
                  timeline.create(map.panel).moveTo(map.x, map.y, 200);

                  if (map.panel.num !== 0) {
                    map.panel.setNum(map.panel.num);
                  }
                }
              }
            }
          }; // メインループ


          _this.update.add(function () {
            return;
          }); // 終了


          _this.finish = function () {
            return;
          }; //次のブロックをセット


          var nowPanel = null;

          var next = function next(isAnim) {
            // 落とすブロックとして取得
            nowPanel = nextMaps[0].panel;

            if (nowPanel) {
              base.append(nowPanel);
              nowPanel.x = maps[1][2].x + mapSize / 2;
              nowPanel.y = maps[1][2].y - 5;
              nowPanel.modified();
            } // ずらす


            for (var i = 0; i < 2; i++) {
              var panel_1 = nextMaps[i + 1].panel;
              nextMaps[i].panel = panel_1;

              if (panel_1) {
                if (isAnim) {
                  timeline.create(panel_1).moveTo(nextMaps[i].x, nextMaps[i].y, 200);
                } else {
                  panel_1.moveTo(nextMaps[i].x, nextMaps[i].y);
                }
              }
            } //最後尾に追加


            var num = scene.random.get(1, 3);
            var panel = panels.pop();
            nextMaps[2].panel = panel;
            panel.x = nextMaps[2].x;
            panel.y = nextMaps[2].y;
            panel.angle = 0;
            panel.isPlus = true;
            panel.setNum(num);

            _this.append(panel); //setColor();

          }; // リセット


          _this.reset = function () {
            for (var y = 1; y < mapH - 1; y++) {
              for (var x = 1; x < mapW - 1; x++) {
                var map = maps[y][x];

                if (map.panel) {
                  panels.unshift(map.panel);
                  map.panel.remove();
                  map.panel = null;
                  map.num = 0;
                }
              }
            }

            if (nowPanel) {
              panels.unshift(nowPanel);
              nowPanel.remove();
              nowPanel = null;
            }

            next(true);
            isMove = false;
            return;
          }; //ネクストブロックを埋める


          for (var i = 0; i < 3; i++) {
            next(false);
          }

          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame; // マップクラス

      var Map =
      /** @class */
      function (_super) {
        __extends(Map, _super);

        function Map() {
          var _this = _super !== null && _super.apply(this, arguments) || this;

          _this.num = 0;
          return _this;
        }

        return Map;
      }(g.FilledRect); // パネルクラス


      var Panel =
      /** @class */
      function (_super) {
        __extends(Panel, _super);

        function Panel(size) {
          var _this = _super.call(this, {
            scene: g.game.scene(),
            width: size,
            height: size,
            src: g.game.scene().assets.panel,
            frames: [0, 1, 2, 3, 4, 5, 6, 7]
          }) || this;

          _this.num = 0;
          _this.isPlus = false; // const scene = this.scene as MainScene;
          // const label = new g.Label({
          // 	scene: scene,
          // 	font: scene.numFont,
          // 	fontSize: 28,
          // 	text: "",
          // 	y: 15,
          // });
          // this.label = label;
          // this.append(label);
          //const colors = ["white", "green", "yellow", "blue", "pink", "cyan", "magenta"];

          _this.setNum = function (num) {
            _this.num = num;
            _this.frameNumber = num - 1;

            _this.modified(); //label.text = "" + Math.pow(2, num);
            //label.text = "" + num;
            //label.invalidate();

          };

          return _this;
        }

        return Panel;
      }(g.FrameSprite);
    }, {
      "@akashic-extension/akashic-timeline": 5
    }],
    9: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics4 = function extendStatics(d, b) {
          _extendStatics4 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics4(d, b);
        };

        return function (d, b) {
          _extendStatics4(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainScene = void 0;

      var tl = require("@akashic-extension/akashic-timeline");

      var Button_1 = require("./Button");

      var Config_1 = require("./Config");

      var MainGame_1 = require("./MainGame");

      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(param) {
          var _this = this;

          param.assetIds = ["img_numbers_n", "img_numbers_n_red", "title", "start", "finish", "score", "time", "panel", "waku", "effect", "ice", "line", "config", "volume", "test", "glyph72", "number_k", "number_b", "number_y", "number_p", "se_start", "se_timeup", "bgm", "se_move", "se_miss", "se_hit", "se_item"];
          _this = _super.call(this, param) || this;
          var timeline = new tl.Timeline(_this);
          var timeline2 = new tl.Timeline(_this);
          var isDebug = false;

          _this.loaded.add(function () {
            g.game.vars.gameState = {
              score: 0
            }; // 何も送られてこない時は、標準の乱数生成器を使う

            _this.random = g.game.random; // ミニゲームチャット用モードの取得と乱数シード設定

            var mode = "";

            if (typeof window !== "undefined") {
              var url = new URL(location.href);
              var seed = url.searchParams.get("date"); // eslint-disable-next-line radix

              if (seed) _this.random = new g.XorshiftRandomGenerator(parseInt(seed));
              mode = url.searchParams.get("mode");
            }

            _this.message.add(function (msg) {
              if (msg.data && msg.data.type === "start" && msg.data.parameters) {
                // セッションパラメータのイベント
                var sessionParameters = msg.data.parameters;

                if (sessionParameters.randomSeed != null) {
                  // プレイヤー間で共通の乱数生成器を生成
                  // `g.XorshiftRandomGenerator` は Akashic Engine の提供する乱数生成器実装で、 `g.game.random` と同じ型。
                  _this.random = new g.XorshiftRandomGenerator(sessionParameters.randomSeed);
                }
              }
            }); // 配信者のIDを取得


            _this.lastJoinedPlayerId = "";
            g.game.join.add(function (ev) {
              _this.lastJoinedPlayerId = ev.player.id;
            }); // 背景

            var bg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#303030",
              opacity: 0
            });

            _this.append(bg);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              bg.opacity = 1.0;
              bg.modified();
            } else {
              bg.opacity = 0.8;
              bg.modified();
            }

            var base = new g.E({
              scene: _this
            });

            _this.append(base);

            base.hide();
            var uiBase = new g.E({
              scene: _this
            });

            _this.append(uiBase);

            uiBase.hide(); // タイトル

            var sprTitle = new g.Sprite({
              scene: _this,
              src: _this.assets.title,
              x: 0
            });

            _this.append(sprTitle);

            timeline.create(sprTitle, {
              modified: sprTitle.modified
            }).wait(isDebug ? 1000 : 5000).moveBy(-800, 0, 200).call(function () {
              bg.show();
              base.show();
              uiBase.show();
              _this.isStart = true;
              reset();
            });
            var glyph = JSON.parse(_this.assets.test.data);
            var numFont = new g.BitmapFont({
              src: _this.assets.img_numbers_n,
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            _this.numFont = numFont;
            var numFontRed = new g.BitmapFont({
              src: _this.assets.img_numbers_n_red,
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            _this.numFontR = numFontRed;
            glyph = JSON.parse(_this.assets.glyph72.data);
            var numFontB = new g.BitmapFont({
              src: _this.assets.number_b,
              map: glyph.map,
              defaultGlyphWidth: 65,
              defaultGlyphHeight: 80
            });
            _this.numFontB = numFontB;
            var numFontK = new g.BitmapFont({
              src: _this.assets.number_k,
              map: glyph.map,
              defaultGlyphWidth: 65,
              defaultGlyphHeight: 80
            });
            _this.numFontK = numFontK;
            _this.numFontY = new g.BitmapFont({
              src: _this.assets.number_y,
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            });
            _this.numFontP = new g.BitmapFont({
              src: _this.assets.number_p,
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            }); // つぎ

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets.score,
              x: 450,
              y: 100,
              height: 32,
              srcY: 64
            })); // スコア

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets.score,
              x: 450,
              y: 0,
              height: 32
            }));
            var score = 0;
            var labelScore = new g.Label({
              scene: _this,
              x: 430,
              y: 35,
              width: 32 * 6,
              fontSize: 32,
              font: numFont,
              text: "0P",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScore);
            var labelScorePlus = new g.Label({
              scene: _this,
              x: 312,
              y: 70,
              width: 32 * 10,
              fontSize: 32,
              font: numFontRed,
              text: "+0",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScorePlus); // タイム

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets.time,
              x: 525,
              y: 320
            }));
            var labelTime = new g.Label({
              scene: _this,
              font: numFont,
              fontSize: 32,
              text: "70",
              x: 565,
              y: 323
            });
            uiBase.append(labelTime); // 開始

            var sprStart = new g.Sprite({
              scene: _this,
              src: _this.assets.start,
              x: 50,
              y: 100
            });
            uiBase.append(sprStart);
            sprStart.hide(); // 終了

            var finishBase = new g.E({
              scene: _this,
              x: 0,
              y: 0
            });

            _this.append(finishBase);

            finishBase.hide();
            var finishBg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#000000",
              opacity: 0.3
            });
            finishBase.append(finishBg);
            var sprFinish = new g.Sprite({
              scene: _this,
              src: _this.assets.finish,
              x: 120,
              y: 100
            });
            finishBase.append(sprFinish); // 最前面

            var fg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#ff0000",
              opacity: 0.0
            });

            _this.append(fg); // リセットボタン


            var btnReset = new Button_1.Button(_this, ["リセット"], 500, 260, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              finishBase.append(btnReset);

              btnReset.pushEvent = function () {
                reset();
              };
            } // ランキングボタン


            var btnRanking = new Button_1.Button(_this, ["ランキング"], 500, 200, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              finishBase.append(btnRanking);

              btnRanking.pushEvent = function () {
                window.RPGAtsumaru.scoreboards.display(1);
              };
            } // 設定ボタン


            var btnConfig = new g.Sprite({
              scene: _this,
              x: 600,
              y: 0,
              src: _this.assets.config,
              touchable: true
            });

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              _this.append(btnConfig);
            } // 設定画面


            var config = new Config_1.Config(_this, 380, 40);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              _this.append(config);
            }

            config.hide();
            btnConfig.pointDown.add(function () {
              if (config.state & 1) {
                config.show();
              } else {
                config.hide();
              }
            });

            config.bgmEvent = function (num) {
              bgm.changeVolume(0.6 * num);
            };

            config.colorEvent = function (str) {
              bg.cssColor = str;
              bg.modified();
            };

            var bgm = _this.assets.bgm.play();

            bgm.changeVolume(isDebug ? 0.0 : 0.3);

            _this.playSound = function (name) {
              _this.assets[name].play().changeVolume(config.volumes[1]);
            }; // ゲームメイン


            var game = new MainGame_1.MainGame(_this);
            base.append(game); // メインループ

            var bkTime = 0;
            var timeLimit = 90;
            var startTime = 0;

            _this.update.add(function () {
              // return;//デバッグ
              if (!_this.isStart) return;
              var t = timeLimit - Math.floor((Date.now() - startTime) / 1000); // 終了処理

              if (t <= -1) {
                fg.cssColor = "#000000";
                fg.opacity = 0.0;
                fg.modified();
                finishBase.show();
                _this.isStart = false;

                _this.playSound("se_timeup");

                timeline.create(_this).wait(2500).call(function () {
                  if (typeof window !== "undefined" && window.RPGAtsumaru) {
                    window.RPGAtsumaru.scoreboards.setRecord(1, g.game.vars.gameState.score).then(function () {
                      btnRanking.show();
                      btnReset.show();
                    });
                  }

                  if (isDebug) {
                    btnRanking.show();
                    btnReset.show();
                  } // ミニゲームチャット用ランキング設定


                  if (mode === "game") {
                    window.parent.postMessage({
                      score: g.game.vars.gameState.score,
                      id: 1
                    }, "*");
                    btnReset.show();
                  }
                });
                game.finish();
                return;
              }

              labelTime.text = "" + t;
              labelTime.invalidate();

              if (bkTime !== t && t <= 5) {
                fg.opacity = 0.1;
                fg.modified();
                timeline.create(_this).wait(500).call(function () {
                  fg.opacity = 0.0;
                  fg.modified();
                });
              }

              bkTime = t;
            }); // スコア加算表示


            var bkTweenScore;

            _this.addScore = function (num) {
              if (score + num < 0) {
                num = -score;
              }

              score += num;
              timeline.create(_this).every(function (e, p) {
                labelScore.text = "" + (score - Math.floor(num * (1 - p))) + "P";
                labelScore.invalidate();
              }, 500);
              labelScorePlus.text = (num >= 0 ? "+" : "") + num;
              labelScorePlus.invalidate();
              if (bkTweenScore) timeline2.remove(bkTweenScore);
              bkTweenScore = timeline2.create(_this).every(function (e, p) {
                labelScorePlus.opacity = p;
                labelScorePlus.modified();
              }, 100).wait(4000).call(function () {
                labelScorePlus.opacity = 0;
                labelScorePlus.modified();
              });
              g.game.vars.gameState.score = score;
              if (typeof window !== "undefined") window.score = score;
            }; // リセット


            var reset = function reset() {
              bkTime = 0;
              startTime = Date.now();
              _this.isStart = true;
              score = 0;
              labelScore.text = "0P";
              labelScore.invalidate();
              labelScorePlus.text = "";
              labelScorePlus.invalidate();
              sprStart.show();
              timeline.create(_this).wait(750).call(function () {
                sprStart.hide();
              });
              btnReset.hide();
              btnRanking.hide();
              fg.opacity = 0;
              fg.modified();
              finishBase.hide();
              startTime = Date.now();
              game.reset();

              _this.playSound("se_start");
            };
          });

          return _this;
        }

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;
    }, {
      "./Button": 6,
      "./Config": 7,
      "./MainGame": 8,
      "@akashic-extension/akashic-timeline": 5
    }],
    10: [function (require, module, exports) {
      var MainScene_1 = require("./MainScene");

      function main(param) {
        // const DEBUG_MODE: boolean = true;
        var scene = new MainScene_1.MainScene({
          game: g.game
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./MainScene": 9
    }]
  }, {}, [10])(10);
});